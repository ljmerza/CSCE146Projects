import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.TreeMap;
/*********************************************************************
 * Intermediate class for counting votes in Lab 07 and HW 5.
 *
 * For the lab, we read votes into an <code>ArrayList</code>,
 * insert into proper order as the data comes in, and then count.
 * votes by running loops.
 *
 * For the HW, this will be done with a <code>TreeMap</code>.
 *
 * Copyright (C) 2011 by Duncan A. Buell.  All rights reserved.
 *
 * @author Duncan A. Buell
 * @version 1.00 2011-03-03
**/
public class VoteCounter
{
/*********************************************************************
 * Instance variables for the class.
**/
  private final String TAG = "VoteCounter: ";

  private int ballotsCast;
  private TreeMap<String,Integer> theMap;

/*********************************************************************
 * Constructor.
**/
  public VoteCounter()
  {
    this.ballotsCast = 0;
    this.theMap = new TreeMap<String,Integer>();
  }

/*********************************************************************
 * Accessors and mutators.
 * None needed; the only methods are general processing methods.
**/

/*********************************************************************
 * General methods.
**/

/*********************************************************************
 * Method to count the votes the easy way.
**/
  private void countTheVotes(PrintWriter outFile, OneLine line)
  {
    Integer theCount = 0;

    String candidate = "";
    String contest = "";
    String key = "";

    if(line.isNewBallot())
    {
      ++ballotsCast;
    }

    key = String.format("%40s %40s",
                        line.getContest().trim(), line.getCandidate().trim());
    theCount = this.theMap.get(key);
    if(theCount == null)
    {
      theCount = 1;
      this.theMap.put(key, theCount);
    }
    else
    {
      ++theCount;
      this.theMap.put(key, theCount);
    }
  } // 

/*********************************************************************
 * Method to do the work for the lab assignment.
 *
 * @param s the <code>Scanner</code> from which to read data.
**/
  public void doTheWork(Scanner inFile, PrintWriter outFile)
  {
    // read the data and fill the arraylist 
    // and sort on the fly
    while(inFile.hasNext())
    {
      OneLine line = new OneLine();
      line = line.readLine(inFile);
      outFile.printf("%s", line.toString());
      this.countTheVotes(outFile, line);
//      this.theList.add(line);
//      this.pullLineForward(this.theList.size()-1);
    }

    // then print
//    outFile.printf("%s", this.toString());

    outFile.printf("A total of %6d ballots were cast.%n", this.ballotsCast);
    for(String key: theMap.keySet())
    {
      int count = this.theMap.get(key);
      outFile.printf("%40s %40s %6d%n",
                      key.substring(0,40).trim(), key.substring(40).trim(), count);
    }

  } // public void doTheWork(Scanner inFile, PrintWriter outFile)

/*********************************************************************
 * Method to do a complete insertionsort on the <code>ArrayList</code>.
  private void insertionSort()
  {
    for(int i = 1; i < this.theList.size(); ++i)
    {
      this.pullLineForward(i);
    }
  } // private void insertionSort()
**/

/*********************************************************************
 * Method to pull one element in the list forward until it is in the
 * proper location.
  private void pullLineForward(int fromWhere)
  {
    for(int j = fromWhere; j >= 1; --j)
    {
      if(this.theList.get(j).compareTo(this.theList.get(j-1)) < 0)
      {
        OneLine temp = new OneLine();
        temp = this.theList.get(j);
        this.theList.set(j, this.theList.get(j-1));
        this.theList.set(j-1, temp);
      }
    }
  } // private void pullLineForward(int fromWhere)
**/

/*********************************************************************
 * Standard <code>toString</code> method.
 *
 * @return the standard return from a <code>toString</code>.
  public String toString()
  {
    String s = "";

    for(OneLine line: theList)
    {
      s += line.toString();
    }

    return s;
  } // public String toString()
**/

} // 
