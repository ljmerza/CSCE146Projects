import java.util.Scanner;
/*********************************************************************
 * Class for handling the individual fields in a record.
 *
 * This is essentially just a wrapper for a data payload, which in
 * this case happens to be a <code>String</code>.  In addition to
 * the obvious wrapper for the <code>element</code>, we have a
 * method to read the <code>element</code> and a method to test
 * whether the <code>element</code> is entirely alphabetic.
 *
 * Copyright(C) 2011 Duncan A. Buell. All rights reserved. 
 *
 * @author Duncan Buell
 * @version 1.00 2011-03-25
**/
public class Record implements IRecord
{
/*********************************************************************
 * Instance variables for the class.
**/
  static final String DUMMYSTRING = "dummy";
  String element;

/*********************************************************************
 * Constructor.
**/
  public Record()
  {
    this.setElement(Record.DUMMYSTRING);
  } // public Record()

/*********************************************************************
 * Constructor.
**/
  public Record(String data)
  {
    this.setElement(data);
  } // public Record(String data)

/*********************************************************************
 * Accessors and mutators.
**/
/*********************************************************************
 * Method to get the <code>element</code>.
 *
 * @return the value of <code>element</code>.
**/
  public String getElement()
  {
    return this.element;
  } // public String getElement()

/*********************************************************************
 * Method to set the <code>element</code>.
 *
 * @param the value of <code>element</code>.
**/
  public void setElement(String what)
  {
    this.element = what;
  } // public void setElement(String what)

/*********************************************************************
 * General methods.
**/
/*********************************************************************
 * Method to compare the <code>element</code> values of records.
 *
 * @return -1, 0, or +1 according as the comparison goes.
**/
  public int compareTo(Record that)
  {
    return this.getElement().compareTo(that.getElement());
  } // public int compareTo(Record that)

/*********************************************************************
 * Method to test whether the <code>element</code> is entirely alpha.
 *
 * @return the answer to the question.
**/
  public boolean isAlpha()
  {
/*
    boolean returnValue;
// here is the slow way
    String alpha = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";

    returnValue = true;
    for(int i = 0; i < this.getElement().length(); ++i)
    {
      if(alpha.indexOf(this.getElement().substring(i,i+1)) < 0)
      {
        returnValue = false;
        break;
      }
    } // for(int i = 0; i < this.getElement().length; ++i)
    return returnValue;
*/

// here is the spiffy way
    return this.getElement().matches("[a-zA-Z]*");

  } // public boolean isAlpha()

/*********************************************************************
 * Method to read the flat file from an input <code>Scanner</code>.
 * Note that this is more or less hard coded. Also that we don't
 * bulletproof the input; among other things we assume that partial
 * records don't appear in the input data.
 *
 * @param inFile the <code>Scanner</code> from which to read.
 * @return this instance of a <code>Record</code>.
**/
  public Record readRecord(Scanner inFile)
  {
    String inString;

    if(inFile.hasNext())
    {
      inString = inFile.next();
      inString = inString.toLowerCase();
      this.setElement(inString);
    } // if(inFile.hasNext())

    return this;
  } // public Record readRecord(Scanner inFile)

/*********************************************************************
 * Method to convert a record to a <code>String</code>.
 *
 * @return the <code>String</code> value of the record.
**/
  public String toString()
  {
    String s;

    s = String.format("%20s",this.getElement());

    return s;
  } // public String toString()

} // public class Record
