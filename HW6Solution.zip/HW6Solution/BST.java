/*********************************************************************
 * Class implementing IBST using a linked structure.
 *
 * This implements a binary search tree using nodes.  In addition to
 * the usual methods for BSTs we have variables and methods for
 * max height and average height of nodes and we can produce a
 * histogram (for diagnostic purposes) of the heights. 
 *
 * Copyright(C) 2011 Duncan A. Buell.  All rights reserved.
 *
 * @author Duncan Buell
 * @version 1.00 2011-03-25
**/
public class BST<T extends Comparable<T>> implements IBST<T>
{
  private static final String TAG = "BST: ";
  private static boolean histogramIsAllocated;
  private int maxHeight, nodeCount; // values exportable
  private int totalHeight; // value used internally
  private int[] heightHisto;
  private BTNode<T> root;

/*********************************************************************
 * Constructor.
**/
  public BST()
  {
    this.histogramIsAllocated = false;
    this.setRoot(null);
    this.setMaxHeight(0);
    this.setNodeCount(0);
    this.totalHeight = 0;
  } // public BT()

/*********************************************************************
 * Accessors and mutators.
**/
/*********************************************************************
 * Method to return the average height of the tree.
 *
 * @return the average height of all nodes.
**/
  public double getAverageHeight()
  {
    return (double) this.totalHeight/this.getNodeCount();
  } // public int getAverageHeight()

/*********************************************************************
 * Method to return the <code>maxHeight</code> of the tree.
 *
 * @return the <code>maxHeight</code>.
**/
  public int getMaxHeight()
  {
    return this.maxHeight;
  } // public int getMaxHeight()

/*********************************************************************
 * Method to return the <code>nodeCount</code> of the tree.
 *
 * @return the <code>nodeCount</code>.
**/
  public int getNodeCount()
  {
    return this.nodeCount;
  } // public int getNodeCount()

/*********************************************************************
 * Method to return the root.
 *
 * @return the root node.
**/
  public BTNode<T> getRoot()
  {
    if(null == this.root)
      throw new RuntimeException("the tree is empty");

    return this.root;
  } // public BTNode getRoot()

/*********************************************************************
 * Mutators.
**/
/*********************************************************************
 * Method to set the <code>maxHeight</code> of the tree.
 *
 * @param the <code>maxHeight</code> to be set.
**/
  private void setMaxHeight(int what)
  {
    this.maxHeight = what;
  } // public void setMaxHeight(int what)

/*********************************************************************
 * Method to set the <code>nodeCount</code> of the tree.
 *
 * @param the <code>nodeCount</code> to be set.
**/
  private void setNodeCount(int what)
  {
    this.nodeCount = what;
  } // public void setNodeCount(int what)

/*********************************************************************
 * Sets the root.
 *
 * @param what the root node.
**/
  private void setRoot(BTNode<T> what)
  {
    if(!isEmpty())
    {
      throw new RuntimeException("tree already has a root");
    }
    this.setNodeCount(1);
    this.root = what;
  } // public void setRoot(BTNode what)

/*********************************************************************
 * General methods..
**/

/*********************************************************************
 * Method to test to see if a data payload is in the tree.
 *
 * Keep track of the number of probes as we are going down. 
 *
 * if the tree is empty
 *   return false
 *
 * else
 *   if we have found the record
 *     return true
 *   else if the payload is less than that of the node
 *     if there is a left child
 *       descend recursively
 *     else
 *       return false
 *   else if the payload is greater than that of the node
 *     if there is a right child
 *       descend recursively
 *     else
 *       return false
 *
 * @param testRecord the data payload to be tested for.
 * @return the answer to the question.
**/
  public boolean contains(T testRecord)
  {
    boolean returnValue;
    int probes;
    BTNode<T> v;

    probes = 0;
    returnValue = true;
    if(isEmpty())
    {
      returnValue = false;
    }
    else
    {
      v = this.getRoot();
      while(null != v)
      {
        ++probes;
        if(0 == testRecord.compareTo(v.getRecord()))
        {
          returnValue = true;
          break;
        }
        else if(0 > testRecord.compareTo(v.getRecord()))
        {
          if(v.hasLeft())
          {
            v = v.getLeft();
          }
          else
          {
            returnValue = false;
            break;
          }
        }
        else if(0 < testRecord.compareTo(v.getRecord()))
        {
          if(v.hasRight())
          {
            v = v.getRight();
          }
          else
          {
            returnValue = false;
            break;
          }
        } // if(0 == v.getRecord().getElement().compareTo(testString))

      } // while(null != v)
    }

    FileUtils.logFile.printf("%s leave 'contains' after %d probes%n",TAG,probes);
    FileUtils.logFile.flush();
    return returnValue;
  } // public boolean contains(T testRecord)

/*********************************************************************
 * Method to insert a node into the tree.
 *
 * First we create a node with the data payload.
 * If the tree is empty, we add the node as the root.
 * else
 *   while not done
 *     if the payload is a dup, return, because we don't add dups
 *
 *     if the new payload is lessequal the node payload
 *       if there is a left child,
 *         then descend recursively 
 *       else (if no left child)
 *         add the node as the left child
 *
 *     if the new payload is greaterequal the node payload
 *       if there is a right child,
 *         then descend recursively 
 *       else (if no right child)
 *         add the node as the right child
 *
 * @param rec the data payload to be inserted into a node in the tree.
 * @return the <code>BTNode</code> inserted.
**/
  public BTNode<T> insert(T rec)
  {
    boolean done = false;
    BTNode<T> v = null;
    BTNode<T> parentToBe = null;
    BTNode<T> returnValue = null;

    v = new BTNode<T>(rec,null,null,null);
    returnValue = v;
    if(this.isEmpty())
    {
      this.setRoot(v);
    }
    else
    {
      parentToBe = root;
      done = false;
      while(!done)
      {
        done = true;
        if(v.getRecord().compareTo(parentToBe.getRecord()) == 0)
        {
          returnValue = null;
        }
        else if((v.getRecord().compareTo(parentToBe.getRecord()) <= 0) &&
            parentToBe.hasLeft())
        {
          parentToBe = parentToBe.getLeft();
          done = false;
        }
        else if((v.getRecord().compareTo(parentToBe.getRecord()) >  0) &&
            parentToBe.hasRight())
        {
          parentToBe = parentToBe.getRight();
          done = false;
        }
      } // while(!done)
      
      v.setParent(parentToBe);
      if(v.getRecord().compareTo(parentToBe.getRecord()) >  0)
      {
        this.setNodeCount(this.getNodeCount() + 1);
        parentToBe.setRight(v);
      }
      else if(v.getRecord().compareTo(parentToBe.getRecord()) <  0)
      {
        this.setNodeCount(this.getNodeCount() + 1);
        parentToBe.setLeft(v);
      }
      else
      {
        returnValue = null;
      } // if(v.getRecord().compareTo(parentToBe.getRecord()) >  0)

    } // if(this.isEmpty())

    if(null != returnValue)
    {
      returnValue.setHeight();
      if(returnValue.getHeight() > this.maxHeight)
      {
        this.maxHeight = returnValue.getHeight();
        FileUtils.logFile.printf("%s new maxHeight %d%n",
                  TAG,this.maxHeight);
        FileUtils.logFile.flush();
      }
    }

    return returnValue;
  } // public BTNode<T> insert(T rec)

/*********************************************************************
 * Method to test whether the tree is empty.
 *
 * @return the answer to the question. 
**/
  public boolean isEmpty()
  {
    return (0 == this.getNodeCount());
  } // public boolean isEmpty()

/*********************************************************************
 * Standard <code>toString</code> method for inorder traversal.
 *
 * CAVEAT: In addition to traversing the tree, we are also setting
 *         the histogram of heights.  And the first time we enter
 *         the method, we allocate the array for the histogram of
 *         heights.
 *
 * @param v the root of the tree to traverse.
 * @return the inorder traversal.
**/
  public String toStringInorder(BTNode<T> v)
  {
    int height;
    String s = "";
    BTNode<T> subRoot = null;

    if(!histogramIsAllocated)
    {
      histogramIsAllocated = true;
      this.heightHisto = new int[this.maxHeight+1];
      for(int i = 0; i <= this.maxHeight; ++i)
        this.heightHisto[i] = 0;
    }

    subRoot = v;
    if(subRoot.hasLeft())
    {
      s += this.toStringInorder(subRoot.getLeft());
    }

    height = subRoot.getHeight();
    this.totalHeight += height;
    ++this.heightHisto[height];
    s += String.format("%s : %4d%n",subRoot.getRecord().toString(),height);

    if(subRoot.hasRight())
    {
      s += this.toStringInorder(subRoot.getRight());
    }

    return s;
  } // public String toStringInorder()

/*********************************************************************
 * Standard <code>toString</code> method for postorder traversal.
 *
 * @param v the root of the tree to traverse.
 * @return the preorder traversal.
**/
  public String toStringPreorder(BTNode<T> v)
  {
    String s = "";
    BTNode<T> subRoot = null;

    subRoot = v;
    s += String.format("%s%n",subRoot.getRecord().toString());

    if(subRoot.hasLeft())
    {
      s += this.toStringPreorder(subRoot.getLeft());
    }

    if(subRoot.hasRight())
    {
      s += this.toStringPreorder(subRoot.getRight());
    }

    return s;
  } // public String toStringPreorder()

/*********************************************************************
 * Standard <code>toString</code> method for postorder traversal.
 *
 * @param v the root of the tree to traverse.
 * @return the postorder traversal.
**/
  public String toStringPostorder(BTNode<T> v)
  {
    String s = "";
    BTNode<T> subRoot = null;

    subRoot = v;

    if(subRoot.hasLeft())
    {
      s += this.toStringPostorder(subRoot.getLeft());
    }

    if(subRoot.hasRight())
    {
      s += this.toStringPostorder(subRoot.getRight());
    }

    s += String.format("%s%n",subRoot.getRecord().toString());

    return s;
  } // public String toStringPostorder()

/*********************************************************************
 * Method to write the tree out completely.
 *
 * Reference DAB (How can you test code without output?).
**/
  public void writeHeightHisto()
  {
    for(int i = 0; i <= this.maxHeight; ++i)
    {
      FileUtils.logFile.printf("%s heightHisto[%2d] = %10d%n",
                TAG,i,this.heightHisto[i]);
      FileUtils.logFile.flush();
    }
  }

} // public class BT implements IBT
