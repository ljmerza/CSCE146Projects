/*********************************************************************
 * Class implementing a node of a binary tree by storing references
 * to an element, a parent node, and a left and right child.
 *
 * Copyright(C) 2011 Duncan A. Buell. All rights reserved.
 *
 * @author Duncan Buell
 * @version 1.00 2011-03-25
**/
public class BTNode<T> implements IBTNode<T>
{
//  private static final String TAG = "BTNode: ";

  private int height;
  private T rec;
  private BTNode<T> left, right, parent;

/*********************************************************************
 * Constructor.
**/
  public BTNode(T rec, BTNode<T> parent, BTNode<T> left, BTNode<T> right)
  {
    this.setRecord(rec);
    this.setParent(parent);
    this.setLeft(left);
    this.setRight(right);
    this.setHeight(); // we do this last because it's computed
  } // public BTNode<T>(Record rec,BTNode parent,BTNode left,BTNode right)

/*********************************************************************
 * Accessors and mutators.
**/
/*********************************************************************
 * Method to get height of a node from the instance variable.
 *
 * @return the height.
**/
  public int getHeight()
  {
    return height;
  } // public int getHeight()

/*********************************************************************
 * Method to set the height of a node by computing it.
**/
  public void setHeight()
  {
    int h;
    BTNode<T> ancestor;

    h = 0;

    ancestor = this;
    while(null != ancestor.getParent())
    {
      ancestor = ancestor.getParent();
      ++h;
    }
    this.height = h;
  } // public int setHeight()

/*********************************************************************
 * Method to get the height of a node by computing it.
**/
  public int getH()
  {
    int h;
    BTNode<T> ancestor;

    h = 0;

    ancestor = this;
    while(null != ancestor.getParent())
    {
      ancestor = ancestor.getParent();
      ++h;
    }
    this.height = h;
    return this.height;
  } // public int getH()

/*********************************************************************
 * Method to get the left child.
 *
 * @return the left child.
**/
  public BTNode<T> getLeft()
  {
    return this.left;
  } // public BTNode<T> getLeft()

/*********************************************************************
 * Method to set the left.
 *
 * @param v the left node.
**/
  public void setLeft(BTNode<T> v)
  {
    this.left = v;
  } // public void setLeft(BTNode<T> v)

/*********************************************************************
 * Method to get the parent.
 *
 * @return the parent.
**/
  public BTNode<T> getParent()
  {
    return this.parent;
  } // public BTNode<T> getParent()

/*********************************************************************
 * Method to set the parent.
 *
 * @param v the parent node
**/
  public void setParent(BTNode<T> v)
  {
    this.parent = v;
  } // public void setParent(BTNode<T> v)

/*********************************************************************
 * Method to return the <code>Record</code> at this position.
 *
 * @return the element
**/
  public T getRecord()
  {
    return this.rec;
  } // public Record getRecord()

/*********************************************************************
 * Method to set the data payload at this position.
 *
 * @param rec the data payload to be set
**/
  public void setRecord(T rec)
  {
    this.rec = rec;
  } // public void setRecord(T rec)

/*********************************************************************
 * Method to get the right child.
 *
 * @return the right child
**/
  public BTNode<T> getRight()
  {
    return this.right;
  } // public BTNode getRight()

/*********************************************************************
 * Method to set the right.
 *
 * @param v the right node.
**/
  public void setRight(BTNode<T> v)
  {
    this.right = v;
  } // public void setRight(BTNode v)

/*********************************************************************
 * General methods.
**/
/*********************************************************************
 * Method to return a boolean as to whether a node has a left child.
 *
 * @return the answer to the question. 
**/
  public boolean hasLeft()
  {
    return (this.getLeft() != null);
  } // public boolean hasLeft()

/*********************************************************************
 * Method to return a boolean as to whether a node has a right child.
 *
 * @return the answer to the question. 
**/
  public boolean hasRight()
  {
    return (this.getRight() != null);
  } // public boolean hasRight()

/*********************************************************************
 * Method to return a boolean as to whether a node is external.
 * Reference page 290.
 *
 * @return the <code>boolean</code> answer to the
 *         <code>isExternal</code> question. 
  public boolean isExternalNode()
  {
    return(this.hasLeft() && this.hasRight());
  } // public boolean isExternal()
**/

/*********************************************************************
 * Method to return a boolean as to whether a node is internal.
 *
 * @return the <code>boolean</code> answer to the
 *         <code>isInternal</code> question. 
  public boolean isInternalNode()
  {
    return(this.hasLeft() || this.hasRight());
  } // public boolean isInternal()
**/

/*********************************************************************
 * Standar <code>toString</code> method.
 *
 * @return the <code>toString</code> version of the node's record.
**/
  public String toString()
  {
    String s = "";
    T rec;

    FileUtils.logFile.flush();

    rec = this.getRecord();
    s = rec.toString();

    return s;
  } // public String toString()

} // public class BTNode implements IBTNode
